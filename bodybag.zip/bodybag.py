
import os
import sys
import time

LINES = [
    (0.0,  "Kaya tangina mo, tangina niya", 2.0),
    (1.0,  "Tangina rin ng mga aso niyo", 1.0),
    (2.0,  "Alam mo na dog lover ako", 1.0),
    (5.0,  "Pero tangina niyong tatlo", 1.0),
    (6.0,  "Pag tinutok ko 'to, takbo nung matalino pa 'yang utak ko", 3.0),
    (9.0,  "Madali lang na pumaldo, pero sana maisip mo", 2.5),
    (11.0, "Na tumabi ka sa gilid kung 'di ka ka-level ng tito mong daga", 3.0),
    (14.0, "Manahimik ka inutil", 1.0),
    (15.0, "Di pa naka-seatbelt, shopping, shopping", 2.0),
    (18.0, "Papunta ng Greenbelt, 'di pa naka-tinted", 2.0),
    (20.0, "Kita mo sumindi, 'pag ako naglabas, alam mo matindi", 2.0),
    (22.0, "Rapper of the year, puta, 'di ko 'yong pinilit", 2.0),
    (22.5, "Mga rapper sakin body bag, body bag, body bag, body bag", 3.0),
]


def type_line(text, type_time):
    char_delay = type_time / len(text)

    for char in text:
        print(char, end="")
        sys.stdout.flush()
        time.sleep(char_delay)


def main():
    os.system("cls" if os.name == "nt" else "clear")

    print("BODY BAG - UNCLE DAGS")
    print()

    input()

    os.system("cls" if os.name == "nt" else "clear")
    print()

    start = time.time()

    for start_at, text, type_time in LINES:
        while time.time() - start < start_at:
            time.sleep(0.01)

        type_line(text, type_time)
        print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
